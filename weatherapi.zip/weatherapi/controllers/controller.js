module.exports = {

    home_function: function(req, res){
        res.json()
    },
    redirect_function: function(req, res){
        res.sendFile(path.resolve("./public/dist/public/index.html"))
    }
}
var controller = require('../controllers/controller');

module.exports = function(app) {
    app.get('/', controller.home_function);
    app.all('*', controller.redirect_function)
}
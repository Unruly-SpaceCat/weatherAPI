import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class HttpService {

  constructor(private _http: HttpClient) { }

  getDallas(){
    return this._http.get('https://api.openweathermap.org/data/2.5/weather?q=Dallas&APPID=fc33611b25058b9e226b24e34e4562f3')
  }
  getSeattle(){
    return this._http.get('https://api.openweathermap.org/data/2.5/weather?q=Seattle&APPID=fc33611b25058b9e226b24e34e4562f3')
  }
  getSanJose(){
    return this._http.get('https://api.openweathermap.org/data/2.5/weather?id=5392171&APPID=fc33611b25058b9e226b24e34e4562f3')
  }
  getBurbank(){
    return this._http.get('https://api.openweathermap.org/data/2.5/weather?q=Burbank&APPID=fc33611b25058b9e226b24e34e4562f3')
  }
  getDC(){
    return this._http.get('https://api.openweathermap.org/data/2.5/weather?id=4140963&APPID=fc33611b25058b9e226b24e34e4562f3')
  }
  getChicago(){
    return this._http.get('https://api.openweathermap.org/data/2.5/weather?q=Chicago&APPID=fc33611b25058b9e226b24e34e4562f3')
  }
}

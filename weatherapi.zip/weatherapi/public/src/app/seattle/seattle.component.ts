import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Params, Router } from '@angular/router';
import { HttpService } from '../http.service';

@Component({
  selector: 'app-seattle',
  templateUrl: './seattle.component.html',
  styleUrls: ['./seattle.component.css']
})
export class SeattleComponent implements OnInit {
  loaded: boolean;
  citydata: any;
  constructor(
    private _route: ActivatedRoute,
    private _router: Router,
    private _httpService: HttpService

  ) {}
  ngOnInit() {
    this.loaded = false
    this.getseattleweather()  
    }

    getseattleweather(){
      console.log("getting seattle weather")
      let observable = this._httpService.getSeattle()
      observable.subscribe(data => {
        this.citydata = data
        this.loaded = true
        console.log(this.citydata)
    }) 
  }
}
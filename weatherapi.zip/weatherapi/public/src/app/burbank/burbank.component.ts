import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Params, Router } from '@angular/router';
import { HttpService } from '../http.service';

@Component({
  selector: 'app-burbank',
  templateUrl: './burbank.component.html',
  styleUrls: ['./burbank.component.css']
})
export class BurbankComponent implements OnInit {
  loaded: boolean;
  citydata: any;
  constructor(
    private _route: ActivatedRoute,
    private _router: Router,
    private _httpService: HttpService
  ) {}
  ngOnInit() {
    this.loaded = false
    this.getburbankweather()  
    }

    getburbankweather(){
      console.log("getting burbank weather")
      let observable = this._httpService.getBurbank()
      observable.subscribe(data => {
        this.citydata = data
        this.loaded = true
        console.log(this.citydata)
    }) 
  }
}
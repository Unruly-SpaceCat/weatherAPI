import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Params, Router } from '@angular/router';
import { HttpService } from '../http.service';

@Component({
  selector: 'app-dc',
  templateUrl: './dc.component.html',
  styleUrls: ['./dc.component.css']
})
export class DcComponent implements OnInit {
  loaded: boolean;
  citydata: any;
  constructor(
    private _route: ActivatedRoute,
    private _router: Router,
    private _httpService: HttpService
  ) {}
  ngOnInit() {
    this.loaded = false
    this.getdcweather()  
    }

    getdcweather(){
      console.log("getting DC weather")
      let observable = this._httpService.getDC()
      observable.subscribe(data => {
        this.citydata = data
        this.loaded = true
        console.log(this.citydata)
    }) 
  }
}
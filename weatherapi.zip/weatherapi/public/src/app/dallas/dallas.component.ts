import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Params, Router } from '@angular/router';
import { HttpService } from '../http.service';

@Component({
  selector: 'app-dallas',
  templateUrl: './dallas.component.html',
  styleUrls: ['./dallas.component.css']
})
export class DallasComponent implements OnInit {
  loaded: boolean;
  citydata: any;
  constructor(
    private _route: ActivatedRoute,
    private _router: Router,
    private _httpService: HttpService
  ) {}
  ngOnInit() {
    this.loaded = false
    this.getdallasweather()  
    }

    getdallasweather(){
      console.log("getting dallas weather")
      let observable = this._httpService.getDallas()
      observable.subscribe(data => {
        this.citydata = data
        this.loaded = true
        console.log(this.citydata)
    }) 
  }
}
import { FTempPipe } from './ftemp.pipe';

describe('FTempPipe', () => {
  it('create an instance', () => {
    const pipe = new FTempPipe();
    expect(pipe).toBeTruthy();
  });
});

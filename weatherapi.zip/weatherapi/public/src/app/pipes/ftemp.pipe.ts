import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'fTemp'
})
export class FTempPipe implements PipeTransform {

  transform(value: number): any {
    var far = (value*9/5-459.67).toFixed(1)
    return far
  }
}
